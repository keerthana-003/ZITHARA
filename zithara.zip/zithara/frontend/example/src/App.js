import Datatable from "./Components/Datatable/Datatable";

function App() {
  return (
    <div>
      <Datatable />
      
    </div>
  );
}

export default App;
